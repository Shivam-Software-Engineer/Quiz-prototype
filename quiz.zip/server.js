const express = require("express");
const cors = require("cors");

const app = express();
const port = 3000;

// Enable CORS
app.use(cors());

// Serve static files (HTML, CSS, JS) for the front-end
app.use(express.static("public"));

// Sample quiz questions
const questions = [
  {
    question: "What is the capital of France?",
    options: ["Paris", "London", "Berlin", "Rome"],
    answer: "Paris",
  },
  {
    question: "Which is the largest planet in our solar system?",
    options: ["Earth", "Mars", "Jupiter", "Saturn"],
    answer: "Jupiter",
  },
  {
    question: "Who wrote 'To Kill a Mockingbird'?",
    options: ["Harper Lee", "J.K. Rowling", "Ernest Hemingway", "F. Scott Fitzgerald"],
    answer: "Harper Lee",
  },
];

// API endpoint to get quiz questions
app.get("/api/questions", (req, res) => {
  res.json(questions);
});

// API endpoint to calculate score
app.post("/api/score", express.json(), (req, res) => {
  const userAnswers = req.body.answers;
  let score = 0;

  questions.forEach((q, index) => {
    if (q.answer === userAnswers[index]) {
      score++;
    }
  });

  res.json({ score, total: questions.length });
});

// Start the server
app.listen(port, () => {
  console.log(`Quiz app running at http://localhost:${port}`);
});
